﻿# lisa-bot
Lisa bot is a Discord bot created for use in the Bang Dream! Girls Band Party community

# Installation
* Rename the file `sample.config.json` to `config.json` in the root directory and modify it as needed. Path to Pickle can be ignored since it's something I do to archive t10 data

* Pip requirements can be found in `requirements.txt`

# Support
Josh#1373 on Discord

https://discord.gg/wDu5CAA

# Issues
The bot won't be able to perform some commands off the start (anything to do with t10 checking pretty much), this is because the script to pull data from the game's API is hidden. I'd be willing to give it out if I know and trust you, but by default it is hidden. Please pm me on Discord if you'd like access.
